package com.example.lemonaidapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class Activity_1 extends AppCompatActivity {
    DatabaseHelper dbh;
    boolean isItAdmin =false;
    String userType;
    String userEmail;
    String AdminEmail;
    String createdByAdmin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_1);

        Button btnRegister = findViewById(R.id.btnRegister);
        final EditText etFirstName = findViewById(R.id.etFName);
        final EditText etLastName = findViewById(R.id.etLName);
        final EditText etPhoneNum = findViewById(R.id.etPh);
        final EditText etEmail = findViewById(R.id.etEm);
        final EditText etMSP = findViewById(R.id.etMSP);
        final EditText etAge = findViewById(R.id.etAge);
        final EditText etPostalCode = findViewById(R.id.etPostal);
        final EditText etPassword = findViewById(R.id.passText);
        final CheckBox hasNoMSP = findViewById(R.id.checkBoxMSP);
        dbh = new DatabaseHelper(this);

        Intent intent = getIntent();
        if(intent.hasExtra("userType")) {
            userType = intent.getStringExtra("userType");
            AdminEmail = intent.getStringExtra("email");
            createdByAdmin = intent.getStringExtra("isAdminC");
            isItAdmin = true;
        }
        else {
            isItAdmin = false;
            createdByAdmin = "no";
        }

        btnRegister.setOnClickListener(new View.OnClickListener() {
            //if user is admin, they will get back to admin page
            //if user is patient creating their own id, they will be logged in as soon as the account is created
            final Intent backtoAdmin = new Intent(Activity_1.this, Activity_5.class);
            final Intent patientLogin = new Intent(Activity_1.this,Activity_9.class);

            @Override
            public void onClick(View v) {
                // If person doesn't have MSP, assign 0 as MSP number

                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();
                String fName = etFirstName.getText().toString();
                String lName = etLastName.getText().toString();
                String phone = etPhoneNum.getText().toString();
                String msp = etMSP.getText().toString();
                String age = etAge.getText().toString();
                String postal = etPostalCode.getText().toString();

                //even if the user writes number, if the checkbox is checked,
                //the app will consider it as no MSP
                if (hasNoMSP.isChecked())
                    msp ="no";
                //check if inputs are empty
               if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password) ||TextUtils.isEmpty(fName) ||
                       TextUtils.isEmpty(lName) || TextUtils.isEmpty(phone) || TextUtils.isEmpty(msp) ||
                       TextUtils.isEmpty(age) || TextUtils.isEmpty(postal)){
                   Toast.makeText(Activity_1.this, "One or more fields are empty", Toast.LENGTH_LONG).show();
               }
               //check if inputs are valid
               else{
                   if (!DataValidation.isValidName(fName)){
                       Toast.makeText(Activity_1.this,"Invalid First Name! No digits!", Toast.LENGTH_LONG).show();
                   }
                   if (!DataValidation.isValidName(lName)){
                       Toast.makeText(Activity_1.this,"Invalid Last Name! No digits!", Toast.LENGTH_LONG).show();
                   }
                   if (!DataValidation.isValidAge(Integer.parseInt(age))){
                       Toast.makeText(Activity_1.this,"Invalid age!", Toast.LENGTH_LONG).show();
                   }
                   if (!DataValidation.isValidPNum(phone)){
                       Toast.makeText(Activity_1.this,"Invalid phone number! Write the pattern of 000-000-0000!", Toast.LENGTH_LONG).show();
                   }
                   if (!DataValidation.isValidPostal(postal)){
                       Toast.makeText(Activity_1.this,"Invalid Postal Code! Write the pattern of X1X 1X1!", Toast.LENGTH_LONG).show();
                   }
               }

                if (DataValidation.isValidName(fName)&&DataValidation.isValidName(lName)
                        && DataValidation.isValidAge(Integer.parseInt(age))
                        && DataValidation.isValidPostal(postal)&& DataValidation.isValidPNum(phone)){

                    //this checks if there is same user already exist before create one
                    //as we uses email address as key to find other values, it should be unique.
                    if (dbh.checkEmailExist(email)) {
                        Toast.makeText(Activity_1.this, "There is user with same email already exist.\nPlease try with other email address", Toast.LENGTH_LONG).show();
                    }
                    else {
                        // if it is created by admin, we already have type of user
                        //and we have to check that it is created by admin
                        // so that patient will be informed to change their password when they log in
                        if(isItAdmin){
                            String officeId = dbh.getdataStaff(AdminEmail,5);
                            if(userType.equals("Patient")){
                                dbh.addrecordPatient(fName, lName, email, phone, msp, age, postal, createdByAdmin);
                            }
                            if(userType.equals("Doctor")){
                                dbh.addrecordStaff(fName,lName,email,phone,"Doctor",officeId);
                            }
                            if(userType.equals("Admin")){
                                dbh.addrecordStaff(fName,lName,email,phone,"Admin",officeId);
                            }
                            if(userType.equals("Cashier")){
                                dbh.addrecordStaff(fName,lName,email,phone,"Cashier",officeId);
                            }
                            dbh.addrecordLogin(email, password);
                            backtoAdmin.putExtra("email", AdminEmail);
                            startActivity(backtoAdmin);
                        }
                        //if it is not created by admin, it is patient account registration.
                        //after the account is created, the patient user will be logged in on their new account
                        else{
                            dbh.addrecordPatient(fName, lName, email, phone, msp, age, postal, "no");
                            userEmail = email;
                            patientLogin.putExtra("email",userEmail);
                            startActivity(patientLogin);
                        }
                        Toast.makeText(Activity_1.this, "Account Successfully created!", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }
}
