package com.example.lemonaidapp;

public class DataValidation {


// Method to check if the postal code is in the correct format
    public static boolean isValidPostal (String postal){
        if  (postal.length()!=7){
            return false;
        }
        for (int i = 0; i<postal.length();i++){
            if (i==0 || i ==2 || i==5){
                if (!Character.isLetter(postal.charAt(i))){
                    return false;
                }
            }
            else if (i ==3){
                if (postal.charAt(i)!=' '){
                    return false;
                }
            }
            else {
                if(!Character.isDigit(postal.charAt(i))){
                    return false;
                }
            }
        }
        return true;
    }

    // Method to check if the name is valid- no digits
    public static boolean isValidName (String name){
        boolean valid = true;
        int lengthOfInput = name.length();
        if(lengthOfInput==0)
            return false;

        for (int i = 0; i<name.length();i++){
            if (!Character.isLetter(name.charAt(i))){
                valid = false;
            }
        }
        return valid;
    }
    // Method to check if Phone number is valid
    public static boolean isValidPNum (String pNum){
        if  (pNum.length()!=12){
            return false;
        }
        for (int i = 0; i<pNum.length();i++){
            if (i==3 || i ==7){
                if (pNum.charAt(i)!='-'){
                    return false;
                }
            }
            else if (!Character.isDigit(pNum.charAt(i))){
                return false;
            }
        }
        return true;
    }
    //Method to check if age is valid
    public static boolean isValidAge(int age){
        return (age>0 && age<120);
    }
}
