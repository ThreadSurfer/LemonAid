package com.example.lemonaidapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Toast;

public class Activity_12 extends AppCompatActivity {

    DatabaseHelper dbh;
    String date;
    String time;
    String didHappen = "TBD";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_12);

        dbh= new DatabaseHelper(this);
        Intent i = getIntent();
        final String patientEmail = i.getStringExtra("patientEmail");
        final String docEmail = i.getStringExtra("docEmail");

        //patient selects date
        CalendarView calendar = findViewById(R.id.cAppointDate);
        final EditText timeOfAppointment = findViewById(R.id.etAppointTime);
        Button btnBookedAppointment = findViewById(R.id.btnAppBooked);
        Button btnReturnToProfile = findViewById(R.id.btnDrProfile);

        calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {

                date = year + "-" + month + "-" + dayOfMonth;
            }
        });
        //The patient clicks book Appointment button
        btnBookedAppointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                time = timeOfAppointment.getText().toString();

                if(date.isEmpty()){
                    Toast.makeText(Activity_12.this, "Select Date", Toast.LENGTH_LONG).show();
                }
                else if(time.isEmpty()){
                    Toast.makeText(Activity_12.this, "Enter Time you'd like to book appointment", Toast.LENGTH_LONG).show();
                }
                else {
                    dbh.addrecordAppt(docEmail, patientEmail,date,time,didHappen);
                    Toast.makeText(Activity_12.this, "Appointment booked for: " +date+" @ " + time, Toast.LENGTH_LONG).show();
                }

            }
        });
        //patient clicks return back to search
        btnReturnToProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Activity_12.this,Activity_10.class);
                startActivity(intent);
            }
        });
    }
}
