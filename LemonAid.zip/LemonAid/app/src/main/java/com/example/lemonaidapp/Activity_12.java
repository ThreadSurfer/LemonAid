package com.example.lemonaidapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class Activity_12 extends AppCompatActivity {

    DatabaseHelper dbh;
    String date; //holds date selected for appointment
    String time; //holds time selected for appointment
    String didHappen = "TBD";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_12);

        dbh= new DatabaseHelper(this);

        //get passed data
        Intent i = getIntent();
        final String patientEmail = i.getStringExtra("patientEmail");
        final String docEmail = i.getStringExtra("docEmail");
        final String docName = i.getStringExtra("docName");

        //Activity widgets
        CalendarView calendar = findViewById(R.id.cAppointDate);
        Button btnBookedAppointment = findViewById(R.id.btnAppBooked);
        Button btnReturnToProfile = findViewById(R.id.btnDrProfile);
        final Spinner selectTime = findViewById(R.id.spTime);

        //initialise adapter , set dropdown view for list of appointment time
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Activity_12.this, android.R.layout.simple_list_item_1,
                getResources().getStringArray(R.array.availableTimes));
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        selectTime.setAdapter(adapter);


        //patient selects date
        calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                date = year + "-" + (month + 1) + "-" + dayOfMonth;
            }
        });
        //The patient clicks book Appointment button
        btnBookedAppointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                time = selectTime.getSelectedItem().toString();

                //checks if date has been selected
                if(date == null){
                    Toast.makeText(Activity_12.this, "Select Date", Toast.LENGTH_LONG).show();
                }
                //check that the time is a valid time input not the hint
                else if(time.equals("Select time...")){
                    Toast.makeText(Activity_12.this, "Invalid time Input! Select time", Toast.LENGTH_LONG).show();
                }
                else {
                    //checking for doctor's availability
                    //validates if selected doctor is available at selected time and date
                    if(dbh.checkApptData(docEmail,date,time)==true){
                        Toast.makeText(Activity_12.this,"Sorry, Doctor " + docName + " Not Availabe! Please book another Time or Date", Toast.LENGTH_LONG).show();
                    }else {
                        //adds res+cord to database if doctor is availabe and input is right.
                        dbh.addrecordAppt(docEmail, patientEmail, date, time, didHappen);
                        Toast.makeText(Activity_12.this, "Appointment booked for: " + date + " @ " + time, Toast.LENGTH_LONG).show();
                    }
                }


            }
        });
        //patient clicks return back to search
        btnReturnToProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Activity_12.this,Activity_10.class);
                intent.putExtra("email",patientEmail);
                startActivity(intent);
            }
        });
    }
}
