package com.example.lemonaidapp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;
import java.util.ArrayList;

public class Activity_16 extends AppCompatActivity {
    DatabaseHelper dbh;
    double payBalance =0;
    double noMSPamt =135.00;
    String userMsgInput;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_16);

        dbh = new DatabaseHelper(this);
        final TextView noMspText = findViewById(R.id.txtMessageNote);
        final EditText patientMsg = findViewById(R.id.editComplainNoMSP);
        final TextView afterMsgPay = findViewById(R.id.txtAddBalance);
        Button btnNoMSPSendMsg = findViewById(R.id.btnSendNoMSP);

        //also show the noMSP fee (How much is it?)
        Intent i = getIntent();
        final String email = i.getStringExtra("email");
        final String docEmail = i.getStringExtra("docEmail");


        noMspText.setText("Please note for users with no MSP online consultation is $" + noMSPamt);

        double amountOwingPrior = Double.parseDouble(dbh.getdataPatient(email,8));
        payBalance = amountOwingPrior + noMSPamt;

        afterMsgPay.setText("After consultation,\nYour Total Balance will become : $"+payBalance);

        btnNoMSPSendMsg.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                userMsgInput = patientMsg.getText().toString();
                if(userMsgInput.equals("")){
                    Toast.makeText(Activity_16.this,"You didn't write any message", Toast.LENGTH_LONG).show();
                }
                else{
                    LocalDate localDate = LocalDate.now();
                    dbh.addrecordComment(docEmail,email,userMsgInput," ");
                    dbh.addrecordTransaction(docEmail,(int)noMSPamt,email,localDate.toString());

                    // update the amount owing in the patient_table ~Darya

                  //  dbh.updateAmountOwed(email,Double.toString(payBalance)); <- I have added this method to be inside the addTransaction, so this is no longer needed (Darya)

                    Intent i = new Intent(Activity_16.this,Activity_15.class);
                    i.putExtra("email",email);

                    startActivity(i);
                }

            }
        });




    }
}
