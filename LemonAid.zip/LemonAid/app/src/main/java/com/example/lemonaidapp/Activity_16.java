package com.example.lemonaidapp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;
import java.util.ArrayList;

public class Activity_16 extends AppCompatActivity {
    DatabaseHelper dbh;
    double payBalance =0;
    double noMSPamt =135.00;
    String userMsgInput;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_16);

        dbh = new DatabaseHelper(this);
        final TextView noMspText = findViewById(R.id.txtMessageNote);
        final EditText patientMsg = findViewById(R.id.editComplainNoMSP);
        final TextView afterMsgPay = findViewById(R.id.txtAddBalance);
        Button btnNoMSPSendMsg = findViewById(R.id.btnSendNoMSP);

        Intent i = getIntent();
        final String email = i.getStringExtra("email");
        //extract the doctor's email address so we can add into database for comment
        final String docEmail = i.getStringExtra("docEmail");

        //Retrieve data of total amount of the patient owes before the patient choose to get online help
        //from the database
        double amountOwingPrior = Double.parseDouble(dbh.getdataPatient(email,8));
        //calculate how much patient will have to pay after the consultation
        payBalance = amountOwingPrior + noMSPamt;


        //Inform the user how much is one time online consultation cost
        noMspText.setText("Please note for users with no MSP online consultation is $" + noMSPamt);
        //Inform the user how much they will have to pay after the online consulation
        afterMsgPay.setText("After consultation,\nYour Total Balance will become : $"+payBalance);

        btnNoMSPSendMsg.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                //gather patient's concern
                userMsgInput = patientMsg.getText().toString();
                //if the comment is empty, notify the patient
                if(userMsgInput.equals("")){
                    Toast.makeText(Activity_16.this,"You didn't write any message", Toast.LENGTH_LONG).show();
                }
                //if there is text entered, update it on the database and send the user to activity_15
                else{
                    //Date information for transaction
                    LocalDate localDate = LocalDate.now();

                    //update database for the comment. the default value will set to ""
                    dbh.addrecordComment(docEmail,email,userMsgInput,"");
                    //update database about the transaction that the patient will owe $135 additionally(noMSPamt)
                    dbh.addrecordTransaction(docEmail,(int)noMSPamt,email,localDate.toString());

                    //send the patient to activity 15 so that they can decide to pay now or later
                    Intent i = new Intent(Activity_16.this,Activity_15.class);
                    i.putExtra("email",email);
                    startActivity(i);
                }

            }
        });




    }
}
