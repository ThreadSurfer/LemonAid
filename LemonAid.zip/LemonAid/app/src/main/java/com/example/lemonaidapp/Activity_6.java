package com.example.lemonaidapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.style.TtsSpan;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Activity_6 extends AppCompatActivity {
    DatabaseHelper dbh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_6);

        dbh = new DatabaseHelper(this);

        final TextView txtUsername = findViewById(R.id.txtUsername);
        final EditText etUsername = findViewById(R.id.etUsername);
        final EditText etMSP = findViewById(R.id.etMSP);
        Button btnFindProfile = findViewById(R.id.btnFindProfile);

        Intent intentUsername = getIntent();
        if(intentUsername != null)
            txtUsername.setText(intentUsername.getStringExtra("email"));

        etUsername.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                etMSP.setText(null);
            }
        });

        etMSP.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                etUsername.setText(null);
            }
        });

        btnFindProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usernameQuery = etUsername.getText().toString();
                String msp = etMSP.getText().toString();

                if (!TextUtils.isEmpty(etUsername.getText().toString())) {

                    String fName = dbh.getdataStaff(usernameQuery, 1);
                    String lName = dbh.getdataStaff(usernameQuery, 2);
                    String phone = dbh.getdataStaff(usernameQuery, 3);
                    String staffType = dbh.getdataStaff(usernameQuery, 4);
                    String officeID = dbh.getdataStaff(usernameQuery, 5);
                    String email = dbh.getdataStaff(usernameQuery, 6);

                    if(fName != null && lName != null && phone != null && staffType != null && officeID != null && email != null) {
                        Intent i = new Intent(Activity_6.this, Activity_7.class);
                        i.putExtra("fName", fName);
                        i.putExtra("lName", lName);
                        i.putExtra("phone", phone);
                        i.putExtra("staffType", staffType);
                        i.putExtra("officeID", officeID);
                        i.putExtra("email", email);
                        i.putExtra("editRequest", true);

                        startActivity(i);
                    }

                    else
                        Toast.makeText(Activity_6.this, "No staff record found", Toast.LENGTH_LONG).show();

            }

                else if (!TextUtils.isEmpty(etMSP.getText().toString())) {
                    String fName = dbh.getDataPatientMsp(msp, 1);
                    String lName = dbh.getDataPatientMsp(msp, 2);
                    String phone = dbh.getDataPatientMsp(msp, 3);
                    String MSP = dbh.getDataPatientMsp(msp, 4);
                    String age = dbh.getDataPatientMsp(msp, 5);
                    String postal = dbh.getDataPatientMsp(msp, 6);

                    if(fName != null && lName != null && phone != null && MSP != null && age != null && postal != null) {
                        Intent i = new Intent(Activity_6.this, Activity_8.class);
                        i.putExtra("fName", fName);
                        i.putExtra("lName", lName);
                        i.putExtra("phone", phone);
                        i.putExtra("msp", MSP);
                        i.putExtra("age", age);
                        i.putExtra("postal", postal);
                        i.putExtra("editRequest", true);

                        startActivity(i);
                    }

                    else
                        Toast.makeText(Activity_6.this, "no patient record found", Toast.LENGTH_LONG).show();

                }

                else {
                    Toast.makeText(Activity_6.this, "Both fields are empty", Toast.LENGTH_LONG).show();
                }
            }

        });
    }
}