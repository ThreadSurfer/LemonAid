package com.example.lemonaidapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.style.TtsSpan;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Activity_6 extends AppCompatActivity {
    DatabaseHelper dbh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_6);

        dbh = new DatabaseHelper(this);

        final EditText etUsername = findViewById(R.id.etUsername);
        final EditText etMSP = findViewById(R.id.etMSP);
        Button btnFindProfile = findViewById(R.id.btnFindProfile);

        etUsername.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                etMSP.setText(null);
            }
        });

        etMSP.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                etUsername.setText(null);
            }
        });

        btnFindProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usernameQuery = etUsername.getText().toString();

                if (!TextUtils.isEmpty(etUsername.getText().toString())) {

                    String fName = dbh.getdataStaff(usernameQuery, 1);
                    Toast.makeText(Activity_6.this, fName, Toast.LENGTH_LONG);

            }

                else {
                    Toast.makeText(Activity_6.this, "No record found", Toast.LENGTH_LONG);
                }
            }

        });
    }
}