package com.example.lemonaidapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Activity_9 extends AppCompatActivity {
    DatabaseHelper dbh;

    ArrayList<String> listMessages = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_9);

        Intent intent = getIntent();

        Button btnLogOut = findViewById(R.id.btnLogOut);
        Button btnFindDoc = findViewById(R.id.btnFindDoc);
        Button btnEditProfile = findViewById(R.id.btnEditProfile);
        Button btnViewPayment = findViewById(R.id.btnPaymentHistory);
        Button btnMakePayment = findViewById(R.id.btnMkPymt);
        TextView greeting = findViewById(R.id.txtGreeting);
        TextView accountBal = findViewById(R.id.txtAccBal);
        ListView listView = findViewById(R.id.listViewComments);

        dbh = new DatabaseHelper(this);



        final String email = intent.getStringExtra("email");
        greeting.setText("Hello, " + dbh.getdataPatient(email, 1));
        accountBal.setText("Amount due: $" + dbh.getdataPatient(email, 8));

        List<HashMap<String, String>> aList = new ArrayList<HashMap<String,String>>();
        listMessages = dbh.getPatientMessages(email);
        for (int i = 0; i < listMessages.size(); i++) {
            HashMap<String, String> hm = new HashMap<String, String>();
            hm.put("message", listMessages.get(i));
            aList.add(hm);
        }
        String[] from = {"message"};
        int[] to = {R.id.messageInfo};
        SimpleAdapter adapter = new SimpleAdapter(getBaseContext(), aList, R.layout.listviewmessages, from, to);
        listView.setAdapter(adapter);




        btnEditProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent activity_8 = new Intent(Activity_9.this, Activity_8.class);
                activity_8.putExtra("email", email);
                startActivity(activity_8);
            }
        });

        btnLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent activity_2 = new Intent(Activity_9.this, Activity_2.class);
                startActivity(activity_2);
            }
        });






        // amountOwe.setText("$" + dbh.getdataPatient(email,8));


        if (dbh.getdataPatient(email,7).equals("yes")){

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Activity_9.this);


            final EditText et = new EditText(Activity_9.this);
            et.setHint("Input New Password!");

            // set prompts.xml to alertdialog builder
            alertDialogBuilder.setView(et);

            // set dialog message
            alertDialogBuilder.setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    String password = et.getText().toString();
                    dbh.updatePassword(email,password);
                    dbh.updatePatientInfo(email, 7, "no");
                }
            });

            // create alert dialog
            AlertDialog alertDialog = alertDialogBuilder.create();
            // show it
            alertDialog.show();
        }

        btnFindDoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Activity_9.this, Activity_10.class);
                intent.putExtra("email",email);
                startActivity(intent);
            }
        });

//
        btnViewPayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Activity_9.this,Activity_13.class);
                i.putExtra("email",email);
                startActivity(i);
            }
        });
        btnMakePayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Activity_9.this,Activity_14.class);
                i.putExtra("email",email);
                startActivity(i);
            }
        });

    }

    @Override
    protected void onResume() {
        TextView accountBal = findViewById(R.id.txtAccBal);
        super.onResume();
        Intent intent = getIntent();
        final String email = intent.getStringExtra("email");
        dbh = new DatabaseHelper(this);
        accountBal.setText("Amount due: $" + dbh.getdataPatient(email, 8));

    }
}
