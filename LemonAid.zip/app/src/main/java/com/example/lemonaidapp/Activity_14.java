package com.example.lemonaidapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Activity_14 extends AppCompatActivity {
    DatabaseHelper dbh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_14);
        dbh = new DatabaseHelper(this);

        Intent i = getIntent();
        final String email = i.getStringExtra("email");

        // References to all elements
        final TextView amountOwe = findViewById(R.id.txtAmountDue);
        Button btnReturn = findViewById(R.id.btnBack);
        Button btnAuthorize = findViewById(R.id.btnAuthPay);
        final TextView payReceived =findViewById(R.id.txtPayReceived);
        // get the amount owing and display
        final double amountOwed = Double.parseDouble(dbh.getdataPatient(email,8));
        amountOwe.setText(" Amount Due:\n $" + amountOwed);


        // return to profile button click
        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (Activity_14.this,Activity_9.class);
                intent.putExtra("email",email);
                startActivity(intent);
            }
        });
        // Authorizing payment button click
        btnAuthorize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // if amount owing is 0
                if (amountOwed == 0){
                    // no payment required
                    payReceived.setText("Balance is $0, no payment required!");

                }
                // if not 0
                else{
                    // show message of payment received
                    payReceived.setText("Payment of " + amountOwed + "$ has been received! \n Thank you!");
                    // reset amount owing and number of reminders
                    dbh.updateAmountOwed(email,"0");
                    dbh.updateNumRemin(email,"0");
                    // new amount owing- 0
                    amountOwe.setText(" Amount Due:\n $" + Integer.parseInt(dbh.getdataPatient(email,8)));
                }
            }
        });


    }
}
