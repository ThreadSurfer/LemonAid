package com.example.lemonaidapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class Activity_8 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_8);

        //Retrieve user type from activity_5
        String userType;
        Intent intent = getIntent();
        if(intent != null) {
            userType = intent.getStringExtra("userType");
        }
    }
}
